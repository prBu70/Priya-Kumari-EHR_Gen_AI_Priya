Dataset Name: NIH ChestX-ray (subset) 
URL: https://nihcc.app.box.com/v/ChestXray-NIHCC 
License: Public domain 
Files Used: 100 samples 
Date Downloaded: 2025-10-01 

Dataset Name: COVID-19 Radiography Database 
URL: https://www.kaggle.com/datasets/tawsifurrahman/covid19-radiography-database
License: CC BY-NC 4.0
Files Used: All downloaded
Date Downloaded: 2025-10-25

Dataset Name: Medical Transcriptions
URL: https://www.kaggle.com/datasets/tawsifurrahman/covid19-radiography-database](https://www.kaggle.com/datasets/tboyle10/medicaltranscriptions
License: CC BY-NC 4.0
Files Used: All downloaded
Date Downloaded: 2025-10-25
